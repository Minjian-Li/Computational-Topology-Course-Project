A clear version of mapper results are available in "mappers" file. 

All the .html files are recommended to be launched via advanced browser instend of IE, for example, Google Chrome. 
